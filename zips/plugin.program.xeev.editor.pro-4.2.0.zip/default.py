import xbmcgui
xbmcgui.Dialog().notification("XEEV", "Addon Running")
xbmcgui.WindowXML("main.xml", addon_path)