import xbmc
xbmc.log("[XEEV] Service Started", xbmc.LOGINFO)